package com.example.applocker

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import com.example.applocker.databinding.ActivityLockBinding

/**
 * Schermata a tutto schermo mostrata sopra l'app protetta.
 * Chiede l'autenticazione tramite impronta digitale (o PIN/pattern del
 * dispositivo come fallback automatico gestito da BiometricPrompt).
 *
 * - Se l'autenticazione ha successo: l'activity si chiude e l'utente
 *   torna a usare l'app come previsto.
 * - Se l'utente annulla: viene rimandato alla schermata Home, per non
 *   lasciare visibile il contenuto dell'app protetta.
 */
class LockActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_TARGET_PACKAGE = "extra_target_package"
    }

    private lateinit var binding: ActivityLockBinding
    private var targetPackage: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLockBinding.inflate(layoutInflater)
        setContentView(binding.root)

        targetPackage = intent.getStringExtra(EXTRA_TARGET_PACKAGE)

        val appLabel = targetPackage?.let { getAppLabel(it) } ?: getString(R.string.app_name)
        binding.lockTitle.text = getString(R.string.lock_title, appLabel)

        binding.buttonUnlock.setOnClickListener { showBiometricPrompt() }

        showBiometricPrompt()
    }

    private fun getAppLabel(packageName: String): String {
        return try {
            val pm = packageManager
            val info = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(info).toString()
        } catch (e: Exception) {
            packageName
        }
    }

    private fun showBiometricPrompt() {
        val biometricManager = BiometricManager.from(this)
        val canAuth = biometricManager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_WEAK or
                BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )

        if (canAuth != BiometricManager.BIOMETRIC_SUCCESS) {
            binding.lockSubtitle.text = getString(R.string.biometric_unavailable)
            return
        }

        val executor = ContextCompat.getMainExecutor(this)
        val biometricPrompt = BiometricPrompt(
            this,
            executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    targetPackage?.let { Prefs.markUnlocked(it) }
                    finish()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    // L'utente ha annullato o ha esaurito i tentativi: torna alla Home
                    // per non lasciare l'app protetta visibile in background.
                    goHome()
                }

                override fun onAuthenticationFailed() {
                    // Tentativo di impronta non riconosciuto: il prompt di sistema
                    // resta aperto e permette di riprovare.
                }
            }
        )

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(getString(R.string.prompt_title))
            .setSubtitle(getString(R.string.prompt_subtitle))
            .setAllowedAuthenticators(
                BiometricManager.Authenticators.BIOMETRIC_WEAK or
                    BiometricManager.Authenticators.DEVICE_CREDENTIAL
            )
            .build()

        biometricPrompt.authenticate(promptInfo)
    }

    private fun goHome() {
        val homeIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_HOME)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        startActivity(homeIntent)
        finish()
    }

    override fun onBackPressed() {
        // Blocca il tasto Indietro: l'unico modo per uscire da qui
        // è autenticarsi oppure andare in Home.
        goHome()
    }
}
