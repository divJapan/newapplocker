package com.example.applocker

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * Servizio di Accessibilità: riceve una notifica ogni volta che cambia
 * la finestra in primo piano (apertura di un'app o cambio Activity).
 * Se il package appartiene alla lista delle app protette e non è stato
 * sbloccato di recente, lancia la LockActivity che mostra il prompt biometrico.
 */
class LockAccessibilityService : AccessibilityService() {

    // Evita di richiamare LockActivity più volte per lo stesso evento
    // mentre l'utente sta già autenticandosi.
    private var currentlyPrompting: String? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        if (event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return

        val packageName = event.packageName?.toString() ?: return

        // Ignora la nostra stessa app (altrimenti la LockActivity si bloccherebbe da sola)
        if (packageName == applicationContext.packageName) {
            currentlyPrompting = null
            return
        }

        if (!Prefs.isLocked(applicationContext, packageName)) {
            return
        }

        if (Prefs.isRecentlyUnlocked(applicationContext, packageName)) {
            return
        }

        if (currentlyPrompting == packageName) {
            return
        }

        currentlyPrompting = packageName

        val intent = Intent(this, LockActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            putExtra(LockActivity.EXTRA_TARGET_PACKAGE, packageName)
        }
        startActivity(intent)
    }

    override fun onInterrupt() {
        // Non serve gestire nulla qui per questo caso d'uso.
    }
}
