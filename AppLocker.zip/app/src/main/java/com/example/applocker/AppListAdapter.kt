package com.example.applocker

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.applocker.databinding.ItemAppBinding

data class AppEntry(
    val packageName: String,
    val label: String,
    val icon: Drawable,
    var locked: Boolean
)

class AppListAdapter(
    private val items: MutableList<AppEntry>,
    private val onToggle: (AppEntry, Boolean) -> Unit
) : RecyclerView.Adapter<AppListAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemAppBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        holder.binding.appIcon.setImageDrawable(item.icon)
        holder.binding.appLabel.text = item.label
        // Rimuove il listener prima di settare lo stato per evitare trigger indesiderati
        holder.binding.appSwitch.setOnCheckedChangeListener(null)
        holder.binding.appSwitch.isChecked = item.locked
        holder.binding.appSwitch.setOnCheckedChangeListener { _, isChecked ->
            item.locked = isChecked
            onToggle(item, isChecked)
        }
    }

    override fun getItemCount(): Int = items.size

    fun submitList(newItems: List<AppEntry>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }
}
