package com.example.applocker

import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.applocker.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: AppListAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = AppListAdapter(mutableListOf()) { app, locked ->
            val current = Prefs.getLockedApps(this)
            if (locked) current.add(app.packageName) else current.remove(app.packageName)
            Prefs.setLockedApps(this, current)
        }

        binding.recyclerApps.layoutManager = LinearLayoutManager(this)
        binding.recyclerApps.adapter = adapter

        binding.buttonEnableAccessibility.setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }

        binding.buttonOverlayPermission.setOnClickListener {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }

        loadInstalledApps()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionBanner()
    }

    private fun updatePermissionBanner() {
        val accessibilityOn = isAccessibilityServiceEnabled()
        binding.buttonEnableAccessibility.text = if (accessibilityOn) {
            getString(R.string.accessibility_enabled)
        } else {
            getString(R.string.enable_accessibility)
        }
        binding.buttonEnableAccessibility.isEnabled = !accessibilityOn
    }

    private fun isAccessibilityServiceEnabled(): Boolean {
        val expectedComponentName = "$packageName/${LockAccessibilityService::class.java.canonicalName}"
        val enabledServices = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        val splitter = TextUtils.SimpleStringSplitter(':')
        splitter.setString(enabledServices)
        while (splitter.hasNext()) {
            if (splitter.next().equals(expectedComponentName, ignoreCase = true)) {
                return true
            }
        }
        return false
    }

    private fun loadInstalledApps() {
        val pm = packageManager
        val lockedApps = Prefs.getLockedApps(this)

        val launchableApps = pm.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { appInfo ->
                // Mostra solo app con un'icona di avvio (esclude servizi di sistema puri)
                pm.getLaunchIntentForPackage(appInfo.packageName) != null &&
                    appInfo.packageName != packageName
            }
            .map { appInfo ->
                AppEntry(
                    packageName = appInfo.packageName,
                    label = pm.getApplicationLabel(appInfo).toString(),
                    icon = pm.getApplicationIcon(appInfo),
                    locked = lockedApps.contains(appInfo.packageName)
                )
            }
            .sortedBy { it.label.lowercase() }

        adapter.submitList(launchableApps)

        if (launchableApps.isEmpty()) {
            Snackbar.make(binding.root, R.string.no_apps_found, Snackbar.LENGTH_LONG).show()
        }
    }
}
