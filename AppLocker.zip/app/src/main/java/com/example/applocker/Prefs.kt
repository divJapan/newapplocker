package com.example.applocker

import android.content.Context

/**
 * Gestisce il salvataggio persistente dei package name delle app
 * scelte dall'utente da proteggere con l'autenticazione.
 */
object Prefs {
    private const val FILE = "app_locker_prefs"
    private const val KEY_LOCKED_APPS = "locked_apps"
    private const val KEY_UNLOCK_TIMEOUT = "unlock_timeout_ms"

    // Dopo uno sblocco riuscito, l'app resta "sbloccata" per questo
    // intervallo di tempo, per evitare di richiedere l'impronta ad ogni
    // singolo passaggio tra schermate della stessa app.
    private const val DEFAULT_TIMEOUT_MS = 5000L

    fun getLockedApps(context: Context): MutableSet<String> {
        val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return prefs.getStringSet(KEY_LOCKED_APPS, emptySet())!!.toMutableSet()
    }

    fun setLockedApps(context: Context, packages: Set<String>) {
        val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        prefs.edit().putStringSet(KEY_LOCKED_APPS, packages).apply()
    }

    fun isLocked(context: Context, packageName: String): Boolean {
        return getLockedApps(context).contains(packageName)
    }

    fun getUnlockTimeoutMs(context: Context): Long {
        val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)
        return prefs.getLong(KEY_UNLOCK_TIMEOUT, DEFAULT_TIMEOUT_MS)
    }

    // Timestamp dell'ultimo sblocco riuscito per ogni package,
    // usato dal servizio per evitare richieste ripetute troppo ravvicinate.
    private val lastUnlockTimestamps = HashMap<String, Long>()

    fun markUnlocked(packageName: String) {
        lastUnlockTimestamps[packageName] = System.currentTimeMillis()
    }

    fun isRecentlyUnlocked(context: Context, packageName: String): Boolean {
        val last = lastUnlockTimestamps[packageName] ?: return false
        return System.currentTimeMillis() - last < getUnlockTimeoutMs(context)
    }
}
